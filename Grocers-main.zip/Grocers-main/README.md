# Grocers
Website for online purchase of groceries.

# About
Online Grocery Store is an eCommerce based web application which We have developed as a sample in which the user can search and find necessary information about any grocery item, can proceed to checkout to buy products. User can create an account, update personal information, can check its past activities, orders and transactions, and cart items.

# Tools Used
-> VS Code
-> Angular
-> NodeJS
-> MongoDB
